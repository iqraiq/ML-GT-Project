import os
import numpy as np
import networkx as nx
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import confusion_matrix
from sklearn.preprocessing import LabelEncoder
import itertools
import matplotlib.pyplot as plt
from collections import defaultdict
import random
from sklearn.metrics import precision_score, recall_score, f1_score


def load_graphs_from_directory(directory):
    graphs = []
    for filename in os.listdir(directory):
        if filename.endswith(".gexf"):
            filepath = os.path.join(directory, filename)
            graph = nx.read_gexf(filepath)
            topic = filename.split("_")[0]  # Extract topic from filename
            graphs.append((graph, topic))
    return graphs

def compute_mcs_similarity(graph1, graph2):
    common_edges = len(set(graph1.edges()).intersection(set(graph2.edges())))
    max_edges = max(len(graph1.edges()), len(graph2.edges()))
    similarity= 1 - common_edges / max_edges #similarity score
    return similarity
def plot_confusion_matrix(cm, classes, title='Confusion matrix', cmap=plt.cm.Blues):
    print('Confusion matrix')
    plt.imshow(cm, interpolation='nearest', cmap=cmap)
    plt.title(title)
    plt.colorbar()
    tick_marks = np.arange(len(classes))
    plt.xticks(tick_marks, classes, rotation=45)
    plt.yticks(tick_marks, classes)

    fmt = 'd'
    thresh = cm.max() / 2.
    for i, j in itertools.product(range(cm.shape[0]), range(cm.shape[1])):
        plt.text(j, i, format(cm[i, j], fmt),
                 horizontalalignment="center",
                 color="white" if cm[i, j] > thresh else "black")

    plt.ylabel('True label')
    plt.xlabel('Predicted label')
    plt.tight_layout()



graph_directory = "graph_representations"
graphs = load_graphs_from_directory(graph_directory)
mcs_graph = nx.Graph()
# Split the data into training and test sets for each topic
test_set = []
train_set = []
topic_to_documents = defaultdict(list)
for graph, topic in graphs:
    topic_to_documents[topic].append((graph, topic))
for topic, documents in topic_to_documents.items():
    test_set.extend(documents[:3])  # Select the first 3 documents for testing
    train_set.extend(documents[3:])  # The rest for training

X_train = [graph for graph, _ in train_set]
y_train = [label for _, label in train_set]
X_test = [graph for graph, _ in test_set]
y_test = [label for _, label in test_set]

# Shuffle the training set
train_set_shuffled = list(zip(X_train, y_train))
random.shuffle(train_set_shuffled)
X_train, y_train = zip(*train_set_shuffled)

# Shuffle the test set
test_set_shuffled = list(zip(X_test, y_test))
random.shuffle(test_set_shuffled)
X_test, y_test = zip(*test_set_shuffled)

num_train_graphs = len(X_train)
num_test_graphs = len(X_test)

mcs_similarity_matrix_train = np.zeros((num_train_graphs, num_train_graphs))
mcs_similarity_matrix_test = np.zeros((num_test_graphs, num_train_graphs))


# Compute MCS similarity matrix for training set
for i, graph1 in enumerate(X_train):
    for j, graph2 in enumerate(X_train):
        if i != j:
            mcs_similarity_matrix_train[i, j] = compute_mcs_similarity(graph1, graph2)
# Compute MCS similarity matrix for test set
for i, graph1 in enumerate(X_test):
    for j, graph2 in enumerate(X_train):
        mcs_similarity_matrix_test[i, j] = compute_mcs_similarity(graph1, graph2)

plt.figure(figsize=(10, 6))
plt.imshow(mcs_similarity_matrix_test, cmap='hot', interpolation='nearest')
plt.colorbar(label='MCS Similarity')
plt.title('MCS Similarity Matrix')
plt.xlabel('Training Graph Index')
plt.ylabel('Test Graph Index')
plt.xticks(np.arange(len(X_train)), np.arange(len(X_train)))
plt.yticks(np.arange(len(X_test)), np.arange(len(X_test)))
plt.show()




labels_encoder = LabelEncoder()
labels_encoder.fit(y_train)

# Train KNN classifier on the training set
K = 5
knn_classifier = KNeighborsClassifier(n_neighbors=K, metric='precomputed')
knn_classifier.fit(mcs_similarity_matrix_train, y_train)

# Predict labels for training and test set
predicted_labels_train = knn_classifier.predict(mcs_similarity_matrix_train)
predicted_labels_test = knn_classifier.predict(mcs_similarity_matrix_test)

# Compute confusion matrix for training and test set
conf_matrix_train = confusion_matrix(y_train, predicted_labels_train, labels=labels_encoder.classes_)
conf_matrix_test = confusion_matrix(y_test, predicted_labels_test, labels=labels_encoder.classes_)

# Compute accuracy for  test set
accuracy_test = np.sum(predicted_labels_test == y_test) / len(y_test)
precision_test = precision_score(y_test, predicted_labels_test, average='weighted')
recall_test = recall_score(y_test, predicted_labels_test, average='weighted')
f1_test = f1_score(y_test, predicted_labels_test, average='weighted')

print("\nTest Set Metrics:")
print(f"Precision: {precision_test *100}")
print(f"Recall: {recall_test *100}")
print(f"F1-score: {f1_test *100}")
print("\nAccuracy:", accuracy_test * 100)
print("Confusion Matrix:")
print(conf_matrix_test)
plt.figure()
plot_confusion_matrix(conf_matrix_test, classes=labels_encoder.classes_,
                      title='Confusion matrix')
plt.show()

# Print true and predicted labels for test set
print("\nTrue and Predicted Labels for Test Documents:")
for true_label in labels_encoder.classes_:
    print(f"\nTrue Label: {true_label}")
    for true, predicted in zip(y_test, predicted_labels_test):
        if true == true_label:
            print(f"True Label: {true}, Predicted Label: {predicted}")

