import os
import networkx as nx
import matplotlib.pyplot as plt

# Directory containing the .gexf files
directory = 'graph_representations'

# Iterate over all files in the directory
for filename in os.listdir(directory):
    if filename.endswith('.gexf'):
        # Load the .gexf file into a NetworkX graph
        filepath = os.path.join(directory, filename)
        graph = nx.read_gexf(filepath)

        # Visualize the graph
        plt.figure(figsize=(8, 6))
        nx.draw(graph, with_labels=True)
        plt.title(filename)
        plt.show()