import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.stem import WordNetLemmatizer
import re
import os


def preprocess_text(text):
    # Tokenization and Normalization
    tokens = word_tokenize(text.lower())

    # Remove punctuation and numerical value using regex
    tokens = [re.sub(r'\d+', '', re.sub(r'[^\w\s]', '', token)) for token in tokens]

    # Remove empty tokens
    tokens = [token for token in tokens if token]

    # Remove stopwords
    stop_words = set(stopwords.words('english'))
    tokens = [token for token in tokens if token not in stop_words]

    # Lemmatization
    lemmatizer = WordNetLemmatizer()
    tokens = [lemmatizer.lemmatize(token) for token in tokens]

    # Reconstruct the preprocessed text
    preprocessed_text = ' '.join(tokens)

    return preprocessed_text


def preprocess_files_in_folder(input_folder):
    for filename in os.listdir(input_folder):
        if filename.endswith('.txt'):  # Process only .txt files, modify as needed
            file_path = os.path.join(input_folder, filename)
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as infile:
                text = infile.read()

            # Preprocess the text
            preprocessed_text = preprocess_text(text)

            # Write preprocessed text back to the same file
            with open(file_path, 'w', encoding='utf-8') as outfile:
                outfile.write(preprocessed_text)

    max500words(input_folder)




def max500words(input_folder):
    for filename in os.listdir(input_folder):
        if filename.endswith('.txt'):  # Process only .txt files, modify as needed
            file_path = os.path.join(input_folder, filename)

            with open(file_path, 'r', encoding='utf-8', errors='ignore') as infile:
                text = infile.read()

            # Preprocess the text
            preprocessed_text = preprocess_text(text)

            # Tokenize the preprocessed text
            preprocessed_words = word_tokenize(preprocessed_text)

            # Take only the first 500 words
            first_500_words = preprocessed_words[:500]

            # Join the words back into a string
            first_500_text = ' '.join(first_500_words)

            # Write the first 500 words back to the same file
            with open(file_path, 'w', encoding='utf-8') as outfile:
                outfile.write(first_500_text)

            print(f"Wrote first 500 words of '{filename}' back to '{file_path}'")

# Example usage:
#input_folder = 'Health and Fitness'  # Replace with your folder path
#preprocess_files_in_folder(input_folder)



