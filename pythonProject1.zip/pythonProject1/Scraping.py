import os
import requests
from bs4 import BeautifulSoup
import re
from collections import Counter
# Web Scraping
# Function to scrape a single link
def scrape_link(link, session):
    try:

        response = session.get(link)
        response.raise_for_status()
        content = response.text

        soup = BeautifulSoup(content, "html.parser")

        # Find all <p> tags in the parsed content
        p_tags = soup.find_all('p')

        # Extract text from each <p> tag and remove extra whitespaces using regular expressions
        p_text = [re.sub(r'\s+', ' ', p.get_text(separator=' ')) for p in p_tags]

        # Join the text from all <p> tags
        p_text_combined = ' '.join(p_text)




        return p_text_combined
    except Exception as e:
        print(f"An error occurred: {e}")


# Function to process a text file containing links
def process_text_file(file_path):
    # Create a directory to store scraped data files
    output_directory = os.path.splitext(file_path)[0] + "_scraped_data"
    os.makedirs(output_directory, exist_ok=True)

    # Create a session for making requests
    session = requests.Session()

    # Read links from the text file and scrape each link
    success_count = 0
    with open(file_path, 'r') as file:
        for index, line in enumerate(file, start=1):
            link = line.strip()  # Remove any leading/trailing whitespaces
            scraped_data = scrape_link(link, session)
            if scraped_data:
                # Create a new file to store scraped data
                output_file = os.path.join(output_directory, f'scraped_data_{index}.txt')
                with open(output_file, 'w', encoding='utf-8') as f:
                    f.write(scraped_data)
                print(f"Scraping of {link} completed and data saved to {output_file}")
            else:
                print(f"Failed to scrape {link}")


# # Provide the file path of your text file
file_path = 'link.txt'
# # Process the text file
process_text_file(file_path)


