import os
import networkx as nx
from nltk.tokenize import word_tokenize


# Function to construct word co-occurrence graph
def construct_word_cooccurrence_graph(tokens, window_size=5):
    graph = nx.Graph()

    for i in range(len(tokens)):
        for j in range(i + 1, min(i + window_size + 1, len(tokens))):
            word1 = tokens[i]
            word2 = tokens[j]
            if not graph.has_edge(word1, word2):
                graph.add_edge(word1, word2, weight=1)
            else:
                graph[word1][word2]['weight'] += 1

    return graph


# Input directories containing preprocessed text files
input_directories = {
    'Hobbies and Lifestyle': 'Hobbies and Lifestyle',
    'Symptom and Diseases': 'Symptom and Diseases',
    'Health and Fitness': 'Health and Fitness'
}

# Output directory to save graph representations
output_directory = 'graph_representations'
if not os.path.exists(output_directory):
    os.makedirs(output_directory)

# Construct graph representation for each preprocessed text file
for topic, input_directory in input_directories.items():
    for filename in os.listdir(input_directory):
        input_file_path = os.path.join(input_directory, filename)
        output_file_path = os.path.join(output_directory, f"{topic}_{os.path.splitext(filename)[0]}.gexf")

        with open(input_file_path, 'r', encoding='utf-8') as file:
            text = file.read()
            tokens = word_tokenize(text)

        graph = construct_word_cooccurrence_graph(tokens)
        nx.write_gexf(graph, output_file_path)
        print(f"Graph representation saved: {output_file_path}")